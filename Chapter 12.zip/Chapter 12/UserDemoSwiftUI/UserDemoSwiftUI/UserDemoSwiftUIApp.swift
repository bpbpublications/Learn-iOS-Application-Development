//
//  UserDemoSwiftUIApp.swift
//  UserDemoSwiftUI
//
//  Created by Rudra on 26/02/21.
//

import SwiftUI

@main
struct UserDemoSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
